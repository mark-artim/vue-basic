// src/store/auth.js
import { defineStore } from 'pinia';

export const useAuthStore = defineStore('auth', {
  state: () => ({
    isAuthenticated: false,
    sessionToken: '',
    sessionId: '',
  }),
  actions: {
    login(token, id) {
      this.isAuthenticated = true;
      this.sessionToken = token;
      this.sessionId = id;
      localStorage.setItem('SessionToken', token);
      localStorage.setItem('SessionId', id);
    },
    logout() {
      this.isAuthenticated = false;
      this.sessionToken = '';
      this.sessionId = '';
      localStorage.removeItem('SessionToken');
      localStorage.removeItem('SessionId');
    },
    initialize() { // 🆕 New method
      const token = localStorage.getItem('SessionToken');
      const id = localStorage.getItem('SessionId');
      if (token) {
        this.isAuthenticated = true;
        this.sessionToken = token;
        this.sessionId = id;
      }
    }
  }
});


