<template>
  <LoginPage />
</template>

<script setup>
import LoginPage from '@/components/LoginPage.vue';

  //
</script>
