<template>
  <div class="price-validation">
    <h1>Price Comparison</h1>

    <input type="file" @change="handleFileUpload" accept=".csv" />

    <button @click="submitData" :disabled="!customerId || !productIds.length || loading">
      {{ loading ? 'Loading...' : 'Submit Data' }}
    </button>

    <p v-if="errorMessage" class="error">{{ errorMessage }}</p>
    <p v-if="fetchingHERPN" class="loading-indicator">🔄 Fetching product cross-references...</p>


    <table v-if="results.length">
      <thead>
        <tr>
          <th v-for="column in tableColumns" :key="column.key">{{ column.label }}</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(item, index) in results" :key="index">
          <td v-for="column in tableColumns" :key="column.key" :class="column.class ? column.class(item) : ''">
            {{ column.format ? column.format(item[column.key]) : item[column.key] }}
          </td>
        </tr>
      </tbody>
    </table>
    <div v-if="failedProducts.length" class="failed-section">
      <h3>Failed Products</h3>
      <ul>
        <li v-for="(fail, index) in failedProducts" :key="index">
          Original ID: {{ fail.originalProductId }} | HER_PN: {{ fail.herProductId || 'N/A' }}
        </li>
      </ul>
    </div>

  </div>
</template>

<script>
import Papa from 'papaparse';
import axios from '@/utils/axios';

export default {
  data() {
    return {
      fetchingHERPN: false,
      failedProducts: [],
      customerId: '',
      productIds: [],
      herProductIdMap: {}, // originalProductId -> HER_PN
      originalProductData: {}, // originalProductId -> parsed CSV row
      results: [],
      errorMessage: '',
      loading: false,
      tableColumns: [
        { key: 'productId', label: 'Product ID' },
        { key: 'herProductId', label: 'HER Product ID' },
        { key: 'upcCode', label: 'UPC Code', format: (val) => val || 'N/A' },
        { key: 'branch', label: 'Branch' },
        { key: 'invoiceNumber', label: 'Invoice #', format: (val) => val || 'N/A' },
        { key: 'actualSellPrice', label: 'Actual Sell Price (USD)', format: (val) => val.toFixed(2) },
        { key: 'productUnitPrice', label: 'Unit Price (API) (USD)', format: (val) => val.value.toFixed(2) },
        { key: 'actualCost', label: 'Actual Cost (USD)', format: (val) => val.toFixed(2) },
        { key: 'productCost', label: 'Product Cost (USD)', format: (val) => val.value.toFixed(2) },
        { key: 'actualCogs', label: 'Actual COGS (USD)', format: (val) => val.toFixed(2) },
        { key: 'productCOGS', label: 'COGS (USD)', format: (val) => val.value.toFixed(2) },
        {
          key: 'priceDifference',
          label: 'Price Difference',
          format: (val) => val.toFixed(2),
          class: (item) => (item.priceDifference < 0 ? 'negative' : 'positive'),
        }
      ],
    };
  },
  methods: {
    async handleFileUpload(event) {
      this.results = [];
      this.failedProducts = [];
      this.errorMessage = '';
      this.productIds = [];
      this.herProductIdMap = {};
      this.originalProductData = {};
      this.customerId = '';
      this.fetchingHERPN = true;
      const file = event.target.files[0];

      if (!file) {
        this.errorMessage = 'Please select a file.';
        return;
      }

      Papa.parse(file, {
        complete: async (result) => {
          const dataRows = result.data.slice(9); // Skip first 9 rows, start at row 10 (index 9)
          const rawData = dataRows.filter((row) => row.length >= 7 && row[0] && row[1]);


          if (rawData.length === 0) {
            this.errorMessage = 'No valid data found in CSV.';
            return;
          }

          const productMap = {};
          const herMap = {};

          for (const row of rawData) {
            const originalProductId = row[0].trim();
            const customerId = row[1].trim();
            const invoiceNumber = row[2] ? row[2].trim() : 'N/A';
            const actualSellPrice = parseFloat(row[3]) || 0;
            const actualCost = parseFloat(row[4]) || 0;
            const actualCogs = parseFloat(row[5]) || 0;
            const branch = row[6].trim();

            this.customerId = customerId;
            productMap[originalProductId] = {
              originalProductId,
              customerId,
              invoiceNumber,
              actualSellPrice,
              actualCost,
              actualCogs,
              branch,
            };
          }

          this.originalProductData = productMap;

          // Fetch HER_PN mappings
          this.fetchingHERPN = true;
          const fetchPromises = Object.keys(productMap).map(async (productId) => {
            try {
              const { data } = await axios.get(`/UserDefined/EDS.PN.XREF?id=${encodeURIComponent(productId)}`);
              herMap[productId] = data.HER_PN;
            } catch (err) {
              console.error(`HER_PN fetch failed for ${productId}`, err);
              herMap[productId] = null;
            }
          });

          await Promise.all(fetchPromises);
          this.herProductIdMap = herMap;
          this.productIds = Object.values(herMap).filter(Boolean);
          this.fetchingHERPN = false;
        },
        header: false,
        skipEmptyLines: true,
      });
    },

    async resolveCustomerXRef(originalCustomerId) {
      try {
        const { data } = await axios.get(`/UserDefined/EDS.CUS.XREF?id=${encodeURIComponent(originalCustomerId)}`);
        return data.F1;
      } catch (err) {
        console.error(`Failed to fetch customer XREF for ${originalCustomerId}`, err);
        this.errorMessage = 'Error resolving customer ID.';
        return null;
      }
    }


    async submitData() {
      if (!this.customerId || !this.productIds.length) {
        this.errorMessage = 'Missing required data.';
        return;
      }

      this.loading = true;
      this.errorMessage = '';
      this.results = [];
      this.failedProducts = [];

      const successfulResults = [];

      const requests = this.productIds.map(async (herProductId) => {
        try {
          const queryParams = `CustomerId=${encodeURIComponent(this.customerId)}&ShowCost=true&ProductId=${encodeURIComponent(herProductId)}`;
          const response = await axios.get(`/ProductPricingMassInquiry?${queryParams}`);
          console.log(`GET CALLED WITH: /ProductPricingMassInquiry?${queryParams}`);
          const apiResults = response.data.results || [];
          console.log(`API results for HER_PN ${herProductId}:`, apiResults);

          apiResults.forEach((item) => {
            const herId = item.productId.toString();
            const originalProductId = Object.keys(this.herProductIdMap).find(
              (key) => this.herProductIdMap[key] === herId
            );
            const local = this.originalProductData[originalProductId] || {};

            successfulResults.push({
              ...item,
              productId: originalProductId,
              herProductId: herId,
              upcCode: item.upcCode || 'N/A',
              invoiceNumber: local.invoiceNumber,
              actualSellPrice: local.actualSellPrice,
              actualCost: local.actualCost,
              actualCogs: local.actualCogs,
              branch: local.branch,
              priceDifference: item.productUnitPrice.value - (local.actualSellPrice || 0),
            });
          });
        } catch (error) {
          console.error(`Failed pricing fetch for HER_PN ${herProductId}`, error);
          const originalId = Object.keys(this.herProductIdMap).find(
            (key) => this.herProductIdMap[key] === herProductId
          );
          this.failedProducts.push({ herProductId, originalProductId: originalId });
        }
      });

      await Promise.all(requests);

      this.results = successfulResults;
      this.loading = false;

      if (this.failedProducts.length) {
        this.errorMessage = `Pricing data could not be retrieved for ${this.failedProducts.length} product(s).`;
      }
    }

  },
};
</script>

<style scoped>
.price-validation {
  max-width: 1000px;
  margin: auto;
  padding: 20px;
  text-align: center;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}

th,
td {
  border: 1px solid #ddd;
  padding: 10px;
  text-align: center;
}

th {
  background-color: #007bff;
  color: white;
  font-weight: bold;
  padding: 12px;
}

td {
  background-color: white;
  color: black;
}

.negative {
  color: red;
  font-weight: bold;
}

.positive {
  color: green;
  font-weight: bold;
}

.failed-section {
  margin-top: 20px;
  color: #cc0000;
  font-weight: bold;
  text-align: left;
}

.loading-indicator {
  margin: 15px 0;
  font-weight: bold;
  color: #007bff;
}
</style>
